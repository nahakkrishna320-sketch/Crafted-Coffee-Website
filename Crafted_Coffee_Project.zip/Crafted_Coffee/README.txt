CRAFTED COFFEE – PROJECT SOURCE

Included:
- index.html
- style.css

How to run:
1. Extract this ZIP.
2. Create an "assets" folder beside index.html.
3. Add the original project images using the filenames listed below.
4. Open index.html in a browser.

Image files referenced by the HTML:
- assets/Vector.png
- assets/blog1.png
- assets/blog2.png
- assets/blog3.png
- assets/blog4.png
- assets/card-1.png
- assets/card2.png
- assets/card3.png
- assets/card4.png
- assets/card5.png
- assets/card6.png
- assets/card7.png
- assets/card8.png
- assets/cf.png
- assets/coffee.png
- assets/gc1.png
- assets/gc2.png
- assets/gc3.png
- assets/gc4.png
- assets/icecoffee.png
- assets/op-1.png
- assets/up-2.png
- assets/up-3.png
- assets/up-4.png

Important:
The uploaded files contained only HTML and CSS, not the image files. Add your original assets folder for the complete visual project.
Font Awesome and Google Fonts load from external CDNs and need an internet connection.
The cart count, links, subscribe and order controls are visual UI elements unless separately connected to functionality.
